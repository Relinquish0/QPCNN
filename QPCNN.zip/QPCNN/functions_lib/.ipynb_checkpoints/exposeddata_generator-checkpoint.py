import numpy as np
import pandas as pd
import os
pd.set_option( 'display.precision',10)

def calculating_f(load_path):
    # Folder creation
    os.makedirs('{}/exposed_data/f'.format(load_path), exist_ok=True)
    os.makedirs('{}/exposed_data/po'.format(load_path), exist_ok=True)

    # Extracting p^t into correct form
    pt = pd.read_excel("{}/Dataset/pt_correlated_output.xlsx".format(load_path))
    pt = pt.to_numpy()#recieve theta in unfaked data
    pt_trans = np.zeros((2*pt.shape[0],2))
    for i in range(pt.shape[0]):
        pt_trans[i,0] = pt[i,6]/(pt[i,6]+pt[i,7])
        pt_trans[i,1] = pt[i,7]/(pt[i,6]+pt[i,7])
        pt_trans[i+pt.shape[0],0] = pt[i,8]/(pt[i,8]+pt[i,9])
        pt_trans[i+pt.shape[0],1] = pt[i,9]/(pt[i,8]+pt[i,9])
    pt_0 = pt_trans[:,0]
    pt_1 = pt_trans[:,1]

    # Extracting p^m
    pm = pd.read_excel("{}/Dataset/pm_correlated_output.xlsx".format(load_path))
    pm = pm.to_numpy()#recieve theta in unfaked data
    pm_0 = pm[:,7]
    pm_1 = pm[:,8]

    for times in range(0,101,1):#'epoch0','epoch1','epoch2','epoch10','epoch100','unfaked data'
        p_n = pd.read_excel("{}/output_Data/QPCNN_output/inference/output_iter0_epoch{}.xlsx".format(load_path,times))
        p_n = p_n.to_numpy()    
        pn_0 = p_n[:,8]
        pn_1 = p_n[:,9]

        f = np.zeros([pm_0.shape[0],2])
        for i in range(0,pm_0.shape[0],1):
            #设b为0，b'为1
            f[i,1] = 1
            j = pn_1[i]*pt_0[i]
            j = np.clip(j, 1e-10, 1 - 1e-10)
            k = pt_1[i]*pn_0[i]
            k = np.clip(k, 1e-10, 1 - 1e-10)
            f[i,0] = j/k
            if f[i,0] >= f[i,1]:
                f[i,0] = 1
                f[i,1] = k/j        
        f = pd.DataFrame(f)
        f.to_excel('{}/exposed_data/f/epoch{}.xlsx'.format(load_path,times), index=False)

    # Repeating this procedure again and set epoch 101 as unfaked data, when f = 1
    f = np.ones([pm_0.shape[0],2])
    f.to_excel('{}/exposed_data/f/epoch101.xlsx', index=False)

